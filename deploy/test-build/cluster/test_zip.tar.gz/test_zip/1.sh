#!/bin/bash -l

#SBATCH --job-name=firecrest_job_test
#SBATCH --time=10:00
#SBATCH --nodes=1


ls /no/file
module list
echo USER!!
echo $USER

sleep 600

# ls $SCRATCH
echo pwd!!
pwd
echo SCRATCH!
echo $SCRATCH
echo SCRATCH!
echo
echo
echo
printenv
echo
echo
echo
ls /etc/profile.d
echo
echo
echo
ls /no/file
# module list
